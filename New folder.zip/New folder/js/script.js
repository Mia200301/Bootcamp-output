let menu_icon = document.querySelector("#menu_icon");

let menu = document.querySelector(".nav_menu");

menu_icon
.addEventListener("click", function() {
    menu.classList.toggle("show")
}
)
